package de.l3s.boilerpipe.demo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import de.l3s.boilerpipe.BoilerpipeExtractor;
import de.l3s.boilerpipe.document.TextDocument;
import de.l3s.boilerpipe.extractors.ArticleExtractor;
import de.l3s.boilerpipe.extractors.CommonExtractors;
import de.l3s.boilerpipe.sax.BoilerpipeSAXInput;
import de.l3s.boilerpipe.sax.HTMLDocument;
import de.l3s.boilerpipe.sax.HTMLFetcher;
import de.l3s.boilerpipe.sax.HTMLHighlighter;

/**
 * Demonstrates how to use Boilerpipe to get the main content, highlighted as HTML.
 * 
 * @author Christian Kohlschütter
 * @see Oneliner if you only need the plain text.
 */
public class HTMLHighlightDemo {
	static int boldText_threshHold = 50;
    static int story_length=500;
    final static HTMLHighlighter hh= HTMLHighlighter.newExtractingInstance();
	public static void main(String[] args) throws Exception {
		try
		{
		System.setProperty("http.agent", "Chrome");
		final HTMLHighlighter hh = HTMLHighlighter.newExtractingInstance();
		hh.setBoldText_threshhold(boldText_threshHold);
    	hh.setMultipleStories(false);
    	hh.setStoryLength_threshhold(story_length);
		URL url = new URL("https://www.bbc.com/urdu/world-47849688");
		url=new URL("https://www.bbc.com/urdu/regional-47520728");
		
		//System.out.println(Jsoup.connect(url.toString()).get().toString());
		System.out.println(hh.getCustomArticle(url));
		System.exit(0);
		//System.out.println(hh.getExtractedHTML(url));
		//System.out.println("output "+ss);
		String path="/home/use1/Downloads/sample";
//		File folder = new File("/home/use5/NetBeansProjects/Boilerpipe/UrduDataset/input/");
//        File[] listOfFiles = folder.listFiles();
////        for (File file : listOfFiles) {
////            if (file.isFile()) {
////            	String html=Read_Doc(file.getPath());
////        		html=html.replaceAll("\\$", "");
////        		String p = "/home/use5/NetBeansProjects/Boilerpipe/UrduDataset/modified/"+file.getName();
////                p = p.replaceAll(".html", ".txt");
////        		String a_s=getArtilcle(html);
////        		Write_Doc(p, a_s);
////        		if(a_s.equals(""))
////        		{
////        			System.out.println(a_s);
////        		}
////            }
////        }
		String html=Read_Doc(path);
		html=html.replaceAll("\\$", "");
		String a_s=getArtilcle(html);
		System.out.println(a_s);
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		System.out.println("Finished");
	}
	private static String Read_Doc(String file_name) {

        Document htmlFile = null;
        String a_s="";
        try
        {
            BufferedReader reader=new BufferedReader(new FileReader(file_name));
            String line=reader.readLine();
            while(line!=null)
            {
                a_s=a_s+line+" ";
                line=reader.readLine();
            }
            
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            System.out.println("Exception at: "+file_name);
        }
        return a_s;
        
    }
	private static String getArtilcle(String html) {

        String a_s="";
        try
        {
            HTMLDocument html1=new HTMLDocument(html.getBytes(), StandardCharsets.UTF_8);
            hh.setBoldText_threshhold(boldText_threshHold);
        	hh.setMultipleStories(false);
        	hh.setStoryLength_threshhold(story_length);
            a_s=hh.getCustomArticle(html1);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return a_s;
    }
	private static void Write_Doc(String path, String a_s) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(path));
            writer.write(a_s);
            writer.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
