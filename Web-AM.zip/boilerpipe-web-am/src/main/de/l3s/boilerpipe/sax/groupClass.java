/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.l3s.boilerpipe.sax;

/**
 *
 * @author use5
 */
public class groupClass {
    int group_no;
    String text;
    String tree;
    int textLength;

    public int getGroup_no() {
        return group_no;
    }

    public String getText() {
        return text;
    }

    public void setGroup_no(int group_no) {
        this.group_no = group_no;
    }

    public void setText(String text) {
        this.text = text;
    }
    public void setTree(String tree)
    {
    	this.tree=tree;
    }
    public String getTree()
    {
    	return this.tree;
    }
    
    public void setTextLength(int len)
    {
    	this.textLength=len;
    }
    public int getTextLength()
    {
    	return this.textLength;
    }
}

