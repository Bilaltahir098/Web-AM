/**
 * boilerpipe
 *
 * Copyright (c) 2009 Christian Kohlschütter
 *
 * The author licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.l3s.boilerpipe.sax;

import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.xerces.parsers.AbstractSAXParser;
import org.cyberneko.html.HTMLConfiguration;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

import de.l3s.boilerpipe.BoilerpipeExtractor;
import de.l3s.boilerpipe.BoilerpipeProcessingException;
import de.l3s.boilerpipe.document.TextBlock;
import de.l3s.boilerpipe.document.TextDocument;
import de.l3s.boilerpipe.extractors.CommonExtractors;
import de.l3s.boilerpipe.sax.groupClass;

/**
 * Highlights text blocks in an HTML document that have been marked as "content"
 * in the corresponding {@link TextDocument}.
 * 
 * @author Christian Kohlschütter
 */
public final class HTMLHighlighter {

	/**
	 * Creates a new {@link HTMLHighlighter}, which is set-up to return the full
	 * HTML text, with the extracted text portion <b>highlighted</b>.
	 */
	public static HTMLHighlighter newHighlightingInstance() {
		return new HTMLHighlighter(false);
	}

	/**
	 * Creates a new {@link HTMLHighlighter}, which is set-up to return only the
	 * extracted HTML text, including enclosed markup.
	 */
	public static HTMLHighlighter newExtractingInstance() {
		return new HTMLHighlighter(true);
	}
	
	private int boldText_threshHold;
	private int story_length;
	private Boolean multipleStories=false;
	private groupClass group_obj;//=new groupClass();
    //private final HashMap<Integer, Integer> hash =new HashMap();
    private final HashMap<String, Integer> hash_tree =new HashMap();
    private final ArrayList<groupClass> g_list = new ArrayList();
    private final ArrayList<groupClass> h_list = new ArrayList();
	/**
	 * BoldText_threshhold is value which is used to get the text written in bold format at the beginning of many articles.
	 * @param value 
	 * the default value is 50 so you can adjust accordingly
	 */
   
	public void setBoldText_threshhold(int value)
	{
		this.boldText_threshHold=value;
	}
	
	/**
	 * Story length is Used to get multiple stories/articles from a single document i.e. from category pages
	 * @param value 
	 * The default value is 500
	 */
	public void setStoryLength_threshhold(int value)
	{
		this.story_length=value;
	}
	
	/**
	 * If you want to get all the stories having characters more than StoryLength_threshhold i.e. second languages too then pass value true otherwise false
	 * @param value
	 * The default value is false
	 */
	public void setMultipleStories(Boolean value)
	{
		this.multipleStories=value;
	}
	
	public int getBoldText_threshhold()
	{
		return this.boldText_threshHold;
	}
	public int getStoryLength_threshhold()
	{
		return this.story_length;
	}
	public Boolean getMultipleStories()
	{
		return this.multipleStories;
	}

	private HTMLHighlighter(final boolean extractHTML) {
		if (extractHTML) {
			setOutputHighlightOnly(true);
			setExtraStyleSheet("");
			setPreHighlight("");
			setPostHighlight("");
		}
	}

	/**
	 * Processes the given {@link TextDocument} and the original HTML text (as a
	 * String).
	 * 
	 * @param doc
	 *            The processed {@link TextDocument}.
	 * @param origHTML
	 *            The original HTML document.
	 * @throws BoilerpipeProcessingException
	 */
	public String process(final TextDocument doc, final String origHTML)
			throws BoilerpipeProcessingException {
		return process(doc, new InputSource(new StringReader(origHTML)));
	}

	/**
	 * Processes the given {@link TextDocument} and the original HTML text (as
	 * an {@link InputSource}).
	 * 
	 * @param doc
	 *            The processed {@link TextDocument}.
	 * @param is
	 *            The original HTML document.
	 * @throws BoilerpipeProcessingException
	 */
	public String process(final TextDocument doc, final InputSource is)
			throws BoilerpipeProcessingException {
		final Implementation implementation = new Implementation();
		implementation.process(doc, is);
		
		String html = implementation.html.toString();
		html=html.replaceAll("$", "");
		if(outputHighlightOnly) {
			Matcher m;

			boolean repeat = true;
			while(repeat) {
				repeat = false;
				m = PAT_TAG_NO_TEXT.matcher(html);
				if(m.find()) {
					repeat = true;
					html = m.replaceAll("");
					//html=m.quoteReplacement("");
				}
				
				m = PAT_SUPER_TAG.matcher(html);
				if(m.find()) {
					repeat = true;
					html = m.replaceAll(m.group(1));	
				}
			}
		}

		return html;
	}
	private static final Pattern PAT_TAG_NO_TEXT = Pattern.compile("<[^/][^>]*></[^>]*>");
	private static final Pattern PAT_SUPER_TAG = Pattern.compile("^<[^>]*>(<.*?>)</[^>]*>$");

	public String process(final URL url, final BoilerpipeExtractor extractor)
			throws IOException, BoilerpipeProcessingException, SAXException {
		final HTMLDocument htmlDoc = HTMLFetcher.fetch(url);

		final TextDocument doc = new BoilerpipeSAXInput(htmlDoc.toInputSource())
				.getTextDocument();
		extractor.process(doc);

		final InputSource is = htmlDoc.toInputSource();

		return process(doc, is);
	}
	/**
	 * This function takes URL  as input and return the extracted text of the article as output.
	 * You can change the behavior of this function using three properties i.e. 1 =>setBoldText_threshhold, 2 =>setStoryLength_threshhold, 3 =>setMultipleStories 
	 * @param URL
	 *            The URL of the document.
	 *            
	 * @throws BoilerpipeProcessingException
	 * 
	 * @return article text or extracted text of article
	 */
	
	public String getExtractedHTML(URL url) throws Exception
	{
		String extracted_html="";
		try
		{
			final BoilerpipeExtractor extractor = CommonExtractors.ARTICLE_EXTRACTOR;
			final HTMLDocument htmlDoc = HTMLFetcher.fetch(url);
			BoilerpipeSAXInput bp= new BoilerpipeSAXInput(htmlDoc.toInputSource());
		    final TextDocument doc =bp.getTextDocument();
			extractor.process(doc);
			final InputSource is = htmlDoc.toInputSource();
			extracted_html= process(doc, is);
			//System.out.println(extracted_html);
		}
		catch(Exception ex)
		{
			throw ex;
		}
		return extracted_html;
	}
	public String getCustomArticle(final URL url)
			throws IOException, BoilerpipeProcessingException, SAXException, Exception {
		String cnt="";
		final BoilerpipeExtractor extractor = CommonExtractors.ARTICLE_EXTRACTOR;
		try {	
		final HTMLDocument htmlDoc = HTMLFetcher.fetch(url);
		//System.out.println(htmlDoc.getData().toString());
		BoilerpipeSAXInput bp= new BoilerpipeSAXInput(htmlDoc.toInputSource());
	    final TextDocument doc =bp.getTextDocument();
		extractor.process(doc);
		final InputSource is = htmlDoc.toInputSource();
		String extracted_html= process(doc, is);
		//System.out.println(extracted_html);
		Document doc1 = Jsoup.parse(extracted_html);
		Elements elements=null;
		if(doc1!=null)
		{
		 elements = doc1.body().select("*");
		} 
        textExtractionAndGrouping(elements);
        final String key_for_max=getKeyForMax();
        cnt = getBoldText(elements)+" ";
        cnt=cnt+getContent(elements, key_for_max);

        // Free all the resources at the end of their usage
        this.group_obj=null;
        this.g_list.clear();
        //this.g_list=null;

		}
		catch(Exception ex)
		{
			throw ex;
		}
		return cnt;
		
	}

	/**
	 * This function takes HTMLDocument  as input and return the extracted text of the article as output.
	 * You can change the behavior of this function using three properties i.e. 1 =>setBoldText_threshhold, 2 =>setStoryLength_threshhold, 3 =>setMultipleStories 
	 * @param html
	 * 			The html is type of HTMLDocument. 
	 * @return
	 *      The extracted text of article is returned.
	 * @throws IOException
	 * @throws BoilerpipeProcessingException
	 * @throws SAXException
	 */
	public String getCustomArticle(HTMLDocument html)
			throws IOException, BoilerpipeProcessingException, SAXException, Exception {
		String cnt="";
		
		try {
		System.out.println(getExtractedHtml(html));
		final Document doc1 = Jsoup.parse(getExtractedHtml(html));
		final Elements elements = doc1.body().select("*");                    
        textExtractionAndGrouping(elements);
        final String key_for_max=getKeyForMax();
        cnt = getBoldText(elements)+" ";
        cnt=cnt+getContent(elements, key_for_max);        
        // Free all the resources at the end of their usage
        this.group_obj=null;
        this.g_list.clear();
		}
		catch(Exception ex)
		{
			throw ex;
		}
		return cnt;
	}
    private String getExtractedHtml(HTMLDocument html) throws Exception
    {
    	final BoilerpipeExtractor extractor;
    	final TextDocument doc;
    	final InputSource is;
    	try {
    		extractor = CommonExtractors.ARTICLE_EXTRACTOR;
    	    doc = new BoilerpipeSAXInput(html.toInputSource()).getTextDocument();
    		extractor.process(doc);
    	    is = html.toInputSource();
    		//String extracted_html=process(doc, is);
    	}
    	catch(Exception ex)
    	{
    		throw ex;
    	}
    	return process(doc,is);
    }
	private String getBoldText(Elements elements) throws Exception
	{
		try
		{
			String content="";
			for (Element element : elements) {
				//System.out.println(element.tagName());
				Boolean isEmpty=element.ownText().equals("");
				Boolean figcaption=element.tagName().equals("figcaption");
				Boolean caption_calass=element.className().equals("caption");
	            if (!isEmpty) {
	            	if(figcaption || caption_calass)
	            	{
	            		// do nothing
	            	}
	            	else
	            	{
	            		content=content+element.ownText();
	            	}
	                //System.out.println(element.ownText().length()+" : "+element.tagName());
	                if((element.ownText().length()>=this.boldText_threshHold)&&(element.tagName().equals("strong")||element.tagName().equals("b")))
	                {
	                	 String s=element.html().replaceAll("<br>"," ");
						 s=s.replaceAll("</", " </"); //append a space among diffirent tags
						 Document d=Jsoup.parse(s);
	                	 return d.text();
	                }
	                if(content.length()>200)
	                {
	                	return "";
	                }
	            }
	           } 
		}
		catch(Exception ex)
		{
			throw ex;
		}
		return "";
	}
	private void textExtractionAndGrouping(Elements elements) throws Exception
	{
		try
		{
			String tagName="";
			for (Element element : elements) {
				tagName=element.tagName();
				 Elements el1=element.parents();
				 for(Element el:el1)
				 {
					 tagName=el.tagName()+tagName;
				 }
				
	            if (!element.ownText().equals("")) {
	                //depth = element.parents().size();
	                this.group_obj = new groupClass();
	                this.group_obj.setTree(tagName);
	                this.group_obj.setGroup_no(element.parents().size());
	                this.group_obj.setText(element.ownText());
	                this.g_list.add(group_obj);
	            }
	        }
			
			for(groupClass obj : this.g_list)
			{
				if (this.hash_tree.containsKey(obj.getTree())) {
	            	this.hash_tree.put(obj.getTree(), this.hash_tree.get(obj.getTree()) + obj.getText().length());
	            } else {
	            	this.hash_tree.put(obj.getTree(), obj.getText().length());
	            }
			}
	        
		}
		catch(Exception ex)
		{
			throw ex;
		}
		
	}
	private String getContent(Elements elements,String key_for_max) throws Exception
	{
		String cnt="";
		try
		{
			String tagName="";
			for (Element element : elements) {
				 tagName=element.tagName();
				 Elements el1=element.parents();
				 for(Element el:el1)
				 {
					 tagName=el.tagName()+tagName;
					 System.out.println("Test0: "+ tagName.equals(key_for_max));
					 System.out.println("Test1: "+ element.html() );
					 if(tagName.equals(key_for_max)&& !element.ownText().equals(""))
					 {
						 String s = element.html(); //.replaceAll("<br>"," ");
						// s=s.replaceAll("</", " </"); //append a space among diffirent tags
						// Document d=Jsoup.parse(s);
						// cnt=cnt+d.text()+" ";
						 System.out.println("Test2: "+s);
					 }
				 }
			}
				     
		}
		catch(Exception ex)
		{
			throw ex;
		}
		System.out.println(cnt);
		return cnt;
	}
	private String getKeyForMax() throws Exception
	{
		String key_for_max = "";
		int max_val=0;
		try
		{
			
	        for (Map.Entry<String, Integer> entry : this.hash_tree.entrySet()) {
	            int val = entry.getValue();
	            String key = entry.getKey();
	            if (val > max_val) {
	                max_val = val;
	                key_for_max = key;
	            }
	        }
		}
		catch(Exception ex)
		{
			throw ex;
		}
		return key_for_max;
	}
	private ArrayList<String> getOtherGroups(String key_for_max) throws Exception
	{
		ArrayList<String>keys=new ArrayList();
		try
		{
			
		        for (Map.Entry<String, Integer> entry : this.hash_tree.entrySet()) {
		            int val = entry.getValue();
		            String key = entry.getKey();
		            if (val > this.story_length||key.equals(key_for_max)) {
		                keys.add(key);
		            }
		        }	
		}
		catch(Exception ex)
		{
			throw ex;
		}
		return keys;
	}
	private boolean outputHighlightOnly = false;
	private String extraStyleSheet = "\n<style type=\"text/css\">\n"
			+ ".x-boilerpipe-mark1 {" + " text-decoration:none; "
			+ "background-color: #ffff42 !important; "
			+ "color: black !important; " + "display:inline !important; "
			+ "visibility:visible !important; }\n" + //
			"</style>\n";
	private String preHighlight = "<span class=\"x-boilerpipe-mark1\">";
	private String postHighlight = "</span>";

	/**
	 * If true, only HTML enclosed within highlighted content will be returned
	 */
	public boolean isOutputHighlightOnly() {
		return outputHighlightOnly;
	}

	/**
	 * Sets whether only HTML enclosed within highlighted content will be
	 * returned, or the whole HTML document.
	 */
	public void setOutputHighlightOnly(boolean outputHighlightOnly) {
		this.outputHighlightOnly = outputHighlightOnly;
	}

	/**
	 * Returns the extra stylesheet definition that will be inserted in the HEAD
	 * element.
	 * 
	 * By default, this corresponds to a simple definition that marks text in
	 * class "x-boilerpipe-mark1" as inline text with yellow background.
	 */
	public String getExtraStyleSheet() {
		return extraStyleSheet;
	}

	/**
	 * Sets the extra stylesheet definition that will be inserted in the HEAD
	 * element.
	 * 
	 * To disable, set it to the empty string: ""
	 * 
	 * @param extraStyleSheet
	 *            Plain HTML
	 */
	public void setExtraStyleSheet(String extraStyleSheet) {
		this.extraStyleSheet = extraStyleSheet;
	}

	/**
	 * Returns the string that will be inserted before any highlighted HTML
	 * block.
	 * 
	 * By default, this corresponds to
	 * <code>&lt;span class=&qupt;x-boilerpipe-mark1&quot;&gt;</code>
	 */
	public String getPreHighlight() {
		return preHighlight;
	}

	/**
	 * Sets the string that will be inserted prior to any highlighted HTML
	 * block.
	 * 
	 * To disable, set it to the empty string: ""
	 */
	public void setPreHighlight(String preHighlight) {
		this.preHighlight = preHighlight;
	}

	/**
	 * Returns the string that will be inserted after any highlighted HTML
	 * block.
	 * 
	 * By default, this corresponds to <code>&lt;/span&gt;</code>
	 */
	public String getPostHighlight() {
		return postHighlight;
	}

	/**
	 * Sets the string that will be inserted after any highlighted HTML block.
	 * 
	 * To disable, set it to the empty string: ""
	 */
	public void setPostHighlight(String postHighlight) {
		this.postHighlight = postHighlight;
	}

	private abstract static class TagAction {
		void beforeStart(final Implementation instance, final String localName) {
		}

		void afterStart(final Implementation instance, final String localName) {
		}

		void beforeEnd(final Implementation instance, final String localName) {
		}

		void afterEnd(final Implementation instance, final String localName) {
		}
	}

	private static final TagAction TA_IGNORABLE_ELEMENT = new TagAction() {
		void beforeStart(final Implementation instance, final String localName) {
			instance.inIgnorableElement++;
		}

		void afterEnd(final Implementation instance, final String localName) {
			instance.inIgnorableElement--;
		}
	};

	private static final TagAction TA_HEAD = new TagAction() {
		void beforeStart(final Implementation instance, final String localName) {
			instance.inIgnorableElement++;
		}

		void beforeEnd(final Implementation instance, String localName) {
			instance.html.append(instance.hl.extraStyleSheet);
		}

		void afterEnd(final Implementation instance, final String localName) {
			instance.inIgnorableElement--;
		}
	};
	private static Map<String, TagAction> TAG_ACTIONS = new HashMap<String, TagAction>();
	static {
		TAG_ACTIONS.put("STYLE", TA_IGNORABLE_ELEMENT);
		TAG_ACTIONS.put("SCRIPT", TA_IGNORABLE_ELEMENT);
		TAG_ACTIONS.put("OPTION", TA_IGNORABLE_ELEMENT);
		TAG_ACTIONS.put("NOSCRIPT", TA_IGNORABLE_ELEMENT);
		TAG_ACTIONS.put("OBJECT", TA_IGNORABLE_ELEMENT);
		TAG_ACTIONS.put("EMBED", TA_IGNORABLE_ELEMENT);
		TAG_ACTIONS.put("APPLET", TA_IGNORABLE_ELEMENT);
		// NOTE: you might want to comment this out:
		TAG_ACTIONS.put("LINK", TA_IGNORABLE_ELEMENT);

		TAG_ACTIONS.put("HEAD", TA_HEAD);
	}

	private final class Implementation extends AbstractSAXParser implements
			ContentHandler {
		StringBuilder html = new StringBuilder();

		private int inIgnorableElement = 0;
		private int characterElementIdx = 0;
		private final BitSet contentBitSet = new BitSet();
		private final HTMLHighlighter hl = HTMLHighlighter.this;

		Implementation() {
			super(new HTMLConfiguration());
			setContentHandler(this);
		}

		void process(final TextDocument doc, final InputSource is)
				throws BoilerpipeProcessingException {
			for (TextBlock block : doc.getTextBlocks()) {
				if (block.isContent()) {
					final BitSet bs = block.getContainedTextElements();
					if (bs != null) {
						contentBitSet.or(bs);
					}
				}
			}

			try {
				parse(is);
			} catch (SAXException e) {
				throw new BoilerpipeProcessingException(e);
			} catch (IOException e) {
				throw new BoilerpipeProcessingException(e);
			}
		}

		public void endDocument() throws SAXException {
		}

		public void endPrefixMapping(String prefix) throws SAXException {
		}

		public void ignorableWhitespace(char[] ch, int start, int length)
				throws SAXException {
		}

		public void processingInstruction(String target, String data)
				throws SAXException {
		}

		public void setDocumentLocator(Locator locator) {
		}

		public void skippedEntity(String name) throws SAXException {
		}

		public void startDocument() throws SAXException {
		}

		public void startElement(String uri, String localName, String qName,
				Attributes atts) throws SAXException {
			TagAction ta = TAG_ACTIONS.get(localName);
			if (ta != null) {
				ta.beforeStart(this, localName);
			}

			// HACK: remove existing highlight
			boolean ignoreAttrs = false;
			if ("SPAN".equalsIgnoreCase(localName)) {
				String classVal = atts.getValue("class");
				if ("x-boilerpipe-mark1".equals(classVal)) {
					ignoreAttrs = true;
				}
			}

			try {
				if (inIgnorableElement == 0) {
					if (outputHighlightOnly) {
//						boolean highlight = contentBitSet
//								.get(characterElementIdx);

//						if (!highlight) {
//							return;
//						}
					}

					html.append('<');
					html.append(qName);
					if (!ignoreAttrs) {
						final int numAtts = atts.getLength();
						for (int i = 0; i < numAtts; i++) {
							final String attr = atts.getQName(i);
							final String value = atts.getValue(i);
							html.append(' ');
							html.append(attr);
							html.append("=\"");
							html.append(xmlEncode(value));
							html.append("\"");
						}
					}
					html.append('>');
				}
			} finally {
				if (ta != null) {
					ta.afterStart(this, localName);
				}
			}
		}

		public void endElement(String uri, String localName, String qName)
				throws SAXException {
			TagAction ta = TAG_ACTIONS.get(localName);
			if (ta != null) {
				ta.beforeEnd(this, localName);
			}

			try {
				if (inIgnorableElement == 0) {
					if (outputHighlightOnly) {
//						boolean highlight = contentBitSet
//								.get(characterElementIdx);

//						if (!highlight) {
//							return;
//						}
					}
					html.append("</");
					html.append(qName);
					html.append('>');
				}
			} finally {
				if (ta != null) {
					ta.afterEnd(this, localName);
				}
			}
		}

		public void characters(char[] ch, int start, int length)
				throws SAXException {
			characterElementIdx++;
			if (inIgnorableElement == 0) {

				boolean highlight = contentBitSet.get(characterElementIdx);

				if (!highlight && outputHighlightOnly) {
					return;
				}

				if (highlight) {
					html.append(preHighlight);
				}
				html.append(xmlEncode(String.valueOf(ch, start, length)));
				if (highlight) {
					html.append(postHighlight);
				}
			}
		}

		public void startPrefixMapping(String prefix, String uri)
				throws SAXException {
		}

	}

	private static String xmlEncode(final String in) {
		if (in == null) {
			return "";
		}
		char c;
		StringBuilder out = new StringBuilder(in.length());

		for (int i = 0; i < in.length(); i++) {
			c = in.charAt(i);
			switch (c) {
			case '<':
				out.append("&lt;");
				break;
			case '>':
				out.append("&gt;");
				break;
			case '&':
				out.append("&amp;");
				break;
			case '"':
				out.append("&quot;");
				break;
			default:
				out.append(c);
			}
		}

		return out.toString();
	}

}
